<?php

namespace App\Controllers;


class Pages extends BaseController
{
    // Pengaturan redireksi ke page yang dibutuhkan
    # Page Menu Utama ----------------------
    public function index()
    {
        return view('pages/menu');
    }

    # Page Masuk Parkir --------------------
    public function pegawai()
    {
        echo view('pages/pegawai');
    }
    public function pengunjung()
    {
        echo view('pages/pengunjung');
    }
    public function welcomePeg()
    {
        echo view('pages/welcomePeg');
    }
    public function welcomePeng()
    {
        echo view('pages/welcomePeng');
    }

    # Page Keluar Parkir -------------------
    public function trmPegawai()
    {
        echo view('pages/trmPegawai');
    }
    public function trmPengunjung()
    {
        echo view('pages/trmPengunjung');
    }

    public function thank()
    {
        echo view('pages/thank');
    }

    # Page Menu Admin ---------------------
    public function admin()
    {
        echo view('pages/admin');
    }
}
