<?php

namespace App\Controllers;

use App\Models\Pengunjung_model;


class Pengunjung extends BaseController
{
    // inisialisasi model
    protected $pengunjungModel;
    public function __construct()
    {
        $this->pengunjungModel = new Pengunjung_model();
    }
    public function index()
    {
        $data = [];
        return view('pages/pengunjung', $data);
    }

    // fungsi untuk melakukan search pada database apabila data yang diinputkan ada pada database
    public function search()
    {
        $this->pengunjungModel = new Pengunjung_model();
        $id = $this->pengunjungModel->request->getVar('id');
        $check = $this->pegawaiModel->search($id);

        if ($check = true) {
            echo view('pages/thank');
        } else {
            echo view('pages/pegawai');
        }
    }
}
