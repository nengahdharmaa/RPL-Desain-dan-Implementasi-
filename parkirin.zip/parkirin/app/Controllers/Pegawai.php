<?php

namespace App\Controllers;

use App\Models\Pegawai_model;


class Pegawai extends BaseController
{
    // inisialisasi model
    protected $pegawaiModel;
    public function __construct()
    {
        $this->pegawaiModel = new Pegawai_model();
    }

    public function index()
    {
        $data = [];
        return view('pages/pegawai', $data);
    }

    // fungsi untuk melakukan search pada database apabila data yang diinputkan ada pada database
    public function search()
    {
        $id = $this->pegawaiModel->input->post('id');
        $check = $this->pegawaiModel->search($id);

        if ($check = true) {
            echo view('pages/thank');
        } else {
            echo view('pages/pegawai');
        }
    }
}
