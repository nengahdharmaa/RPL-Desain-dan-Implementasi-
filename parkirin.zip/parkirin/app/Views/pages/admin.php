<!DOCTYPE html>
<html>

<head>
    <title>Parkirin</title>
    <link rel="stylesheet" href="style/menu.css">
</head>

<body>
    <h1>Selamat Datang</h1>
    <div class="content">
        <a id="btnPegawai" class="buttons" href="pegawai.html">
            <img src="images/employee.png" alt="pegawai">
            <h2>Pegawai</h2>
        </a>
        <a id="btnPengunjung" class="buttons" href="pengunjung.html">
            <img src="images/id-card.png" alt="pengunjung">
            <h2>Pengunjung</h2>
        </a>
    </div>
</body>

</html>