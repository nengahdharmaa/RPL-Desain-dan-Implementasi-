<?php

namespace App\Models;

use CodeIgniter\Model;

class Pegawai_Model extends Model
{
    protected $table = 'pegawai';
    public function __construct()
    {
        $db = \Config\Database::connect();
    }


    public function search($id_pegawai)
    {
        $builder = $this->db->table('pegawai');
        $builder->where('id_pegawai', $id_pegawai);
        if ($builder->countAllResults() > 0) {
            return true;
        } else {
            return false;
        }
    }
}
