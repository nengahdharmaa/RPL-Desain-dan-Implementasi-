<?php

namespace App\Models;

use CodeIgniter\Model;

class Pengunjung_Model extends Model
{
    // Melakukan koneksi ke database
    protected $table = 'pengunjung';
    public function __construct()
    {
        $db = \Config\Database::connect();
    }


    // melakukan pengecekan apakah id pegawai yang diinput terdapat pada database dan mengembalikan true apabila data ditemukan dan false untuk sebaliknya
    public function search($kendaraan, $plat_nomor)
    {
        $where = array(
            'kendaraan' => $kendaraan,
            'plat_nomor' => $plat_nomor
        );
        $builder = $this->db->table('pengunjung');
        $builder->where($where);
        if ($builder->countAllResults() > 0) {
            return true;
        } else {
            return false;
        }
    }
}
